let passos = 0;
let historico = [];
let metaDiaria = 1000; // Meta padrão
let atividades = [];

// Função para atualizar o contador na tela
function atualizarContador() {
    document.getElementById('contador').innerText = passos;
    document.getElementById('historico').innerText = "Histórico: " + historico.join(", ");
}

// Evento de clique no botão para simular passos
document.getElementById('incrementar').addEventListener('click', function() {
    passos++;
    historico.push(passos);
    atividades.push({ data: new Date(), tipo: 'Passo' });
    atualizarContador();
    verificarMeta();
});

// Evento de clique no botão para resetar o contador
document.getElementById('resetar').addEventListener('click', function() {
    passos = 0;
    historico = [];
    atividades = [];
    atualizarContador();
});

// Função para verificar se a meta foi atingida
function verificarMeta() {
    if (passos >= metaDiaria) {
        alert("Parabéns! Você atingiu sua meta de " + metaDiaria + " passos!");
    }
}

// Evento para definir a meta diária
document.getElementById('metaDiaria').addEventListener('change', function() {
    metaDiaria = parseInt(this.value);
});

// Função para gerar relatórios
document.getElementById('gerarRelatorio').addEventListener('click', function() {
    const relatorio = atividades.map(atividade => {
        return `Data: ${atividade.data.toLocaleString()}, Tipo: ${atividade.tipo}`;
    }).join("<br>");
    document.getElementById('relatorio').innerHTML = relatorio || "Nenhuma atividade registrada.";
});

// Função para detectar passos em dispositivos móveis
if (window.DeviceMotionEvent) {
    window.addEventListener('devicemotion', function(event) {
        const acceleration = event.acceleration;
        if (acceleration.x > 1 || acceleration.y > 1 || acceleration.z > 1) {
            passos++;
            historico.push(passos);
            atividades.push({ data: new Date(), tipo: 'Passo' });
            atualizarContador();
            verificarMeta();
        }
    });
} else {
    alert("Este dispositivo não suporta a API de movimento.");
}